package com.sust.web.controller.admin;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;

import com.github.pagehelper.PageInfo;
import com.sust.bean.TBuild;
import com.sust.bean.TLog;
import com.sust.bean.TUser;
import com.sust.service.IBulidServcie;
import com.sust.service.ILogServcie;
import com.sust.service.IUserService;
/*
 * 建筑管理
 */
@Controller
public class buildManagerController{
	@Autowired
	private IBulidServcie IBulidServcie;
	@Autowired
	private IUserService userService;
	@Autowired
	private ILogServcie logService;
	// 跳转到建筑管理，携带建筑的信息
	@RequestMapping("/toBuildManager/{curPage}")
	public String tobuildManager(Model model,@PathVariable int curPage) throws Exception {
		PageInfo<TBuild> list = IBulidServcie.selectAllBuildPage(curPage, 10);
		for (TBuild tBuild : list.getList()) {
			TUser user = userService.selectTUserById(tBuild.getUserId());
			tBuild.setUser(user);
		}
		model.addAttribute("pageInfo", list);
		return "/admin/buildManager.jsp";
	}
	// 跳转到新增建筑信息
	@RequestMapping("/toAddBuild")
	public String addBuildManager(Model model) throws Exception {
		List<TUser> Userlist = userService.selectAllUser();
		model.addAttribute("UserList", Userlist);
		return "/admin/addBuild.jsp";
	}
	// 提交添加建筑信息
	@RequestMapping(value="/addBuildSuccess",method = RequestMethod.POST)
	public  void addBuildSuccess(@RequestParam("image")MultipartFile file, MultipartHttpServletRequest request) throws Exception {
		//IBulidServcie.insertBuild(build);
	}

	// 跳转到修改建筑信息
	@RequestMapping("/toUpdateBuild/{id}")
	public String updateBuildManager(Model model, @PathVariable int id) throws Exception {
		TBuild build = IBulidServcie.selectBuildById(id);
		model.addAttribute("build", build);
		return "/admin/updateBuild.jsp";
	}
	// 提交修改
	@RequestMapping("/updateBuildSuccess")
	public @ResponseBody void updateBuildSuccess(TBuild build) throws Exception {
		IBulidServcie.updateBuildById(build);
		TLog log = new TLog(2, "修改建筑信息："+build.getName(),new Date());
		logService.insertLog(log);
	}

	// 跳转到建筑详情
	@RequestMapping("/toShowBuild/{id}")
	public String selectBuildManager(Model model, @PathVariable int id) throws Exception {
		TBuild build = IBulidServcie.selectBuildById(id);
		model.addAttribute("build", build);
		return "/admin/showBuild.jsp";
	}

	// 删除建筑详情
	@RequestMapping("/toDeleteBuild/{id}")
	public @ResponseBody void deleteBuildManager(@PathVariable int id) throws Exception {
		TBuild build = IBulidServcie.selectBuildById(id);
		IBulidServcie.deleteBuildById(id);
		TLog log = new TLog(2, "删除建筑信息："+build.getName(),new Date());
		logService.insertLog(log);
	}

}
