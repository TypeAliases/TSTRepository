package com.sust.web.controller.admin;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class techniqueManagerController {
	
	
	
	@RequestMapping("toTechniqueManager/{curPage}")
	public String toTechniqueManager(Model model,@PathVariable int curPage) {
		
		return "/admin/techniqueManager.jsp";
	}

}
