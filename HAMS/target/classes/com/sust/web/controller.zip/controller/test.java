package com.sust.web.controller;

import java.io.File;
import java.io.IOException;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.io.FileUtils;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

@Controller
@RequestMapping("/SpringMVCDemo1")
public class test {

    /**
     * 上传单个文件
     * 通过MultipartFile读取文件信息，如果文件为空跳转到结果页并给出提示；
     * 如果不为空读取文件流并写入到指定目录，最后将结果展示到页面
     * @param multipartFile
     * @PostMapping 是一个组合注解，是@RequestMapping(method = RequestMethod.POST)的缩写。
     */
    @RequestMapping("/upload")
    public String uploadSingleFile(@RequestParam("file") MultipartFile multipartFile, HttpServletRequest request){
        if (multipartFile.isEmpty()){
            request.setAttribute("message",  "Please select a file to upload '");
            return "/upload_result.jsp";
        }

        try {
            String contentType = multipartFile.getContentType();
            String originalFilename = multipartFile.getOriginalFilename();
            byte[] bytes = multipartFile.getBytes();
            System.out.println("上传文件名为-->" + originalFilename);
            System.out.println("上传文件类型为-->" + contentType);
            System.out.println("上传文件大小为-->"+bytes.length);

            //filePath为存储路径
            String filePath = "/Users/adam/staticResourcesTest";
            System.out.println("filePath-->" + filePath);
            //存储在staticResourcesTest下的imgupload文件夹下
            File parentPath = new File(filePath, "imgupload");
            System.out.println("上传目的地为-->"+parentPath.getAbsolutePath());
            try {
                File destFile = new File(parentPath,originalFilename);//上传目的地
                FileUtils.writeByteArrayToFile(destFile,multipartFile.getBytes());
            } catch (Exception e) {
                e.printStackTrace();
            }
            request.setAttribute("message",  "You successfully uploaded '" + multipartFile.getOriginalFilename() + "'");

        } catch (IOException e) {
            e.printStackTrace();
        }
        return "/index.jsp";
    }

   
}
