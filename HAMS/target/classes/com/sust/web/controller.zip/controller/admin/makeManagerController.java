package com.sust.web.controller.admin;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.github.pagehelper.PageInfo;
import com.sust.bean.BuildMaintenance;
import com.sust.bean.BuildMake;
import com.sust.bean.TBuild;
import com.sust.bean.TLog;
import com.sust.bean.TMaintenance;
import com.sust.bean.TMake;
import com.sust.bean.TUser;
import com.sust.service.IBuildMakeService;
import com.sust.service.IBulidServcie;
import com.sust.service.ILogServcie;
import com.sust.service.IMakeService;

@Controller
public class makeManagerController {
	@Autowired
	private IMakeService makeService;
	@Autowired
	private IBulidServcie IBulidServcie;
	@Autowired
	private ILogServcie logService;
	@Autowired
	private IBuildMakeService buildMakeService;
	// 跳转到构造信息
	@RequestMapping("/toMakeManager/{curPage}")
	public String tobuildManager(Model model,@PathVariable int curPage) throws Exception {
		PageInfo<BuildMake> list = buildMakeService.selectAllBuildMakePage(curPage, 10);
		if (list.getList().size()!=0) {
		for (BuildMake make : list.getList()) {
			Integer buildId = make.getBuildId();
			Integer makeId = make.getMakeId();
			TBuild tBuild = IBulidServcie.selectBuildById(buildId);
			TMake tMake = makeService.selectMakeById(makeId);
			make.setBuild(tBuild);
			make.setMake(tMake);
		}
		}
		model.addAttribute("pageInfo", list);
		return "/admin/makeManager.jsp";
	}
	// 跳转添加构造信息记录
		@RequestMapping("/toAddMake")
		public String addMakeManager(Model model) throws Exception {
			List<TBuild> list = IBulidServcie.selectAllBuilds();
			model.addAttribute("builds", list);
			return "/admin/addMake.jsp";
		}

		// 成功添加构造记录
		@RequestMapping("/addMakeSuccess")
		public @ResponseBody void addMakeSuccess(TMake tMake,Integer buildid) throws Exception {
			makeService.insertMake(tMake);
			BuildMake buildMake = new BuildMake();
			TMake make = makeService.selectLast();
			buildMake.setBuildId(buildid);
			buildMake.setMakeId(make.getId());
			buildMakeService.insertBuildMake(buildMake);
		}
	
	// 跳转到构造详情
	@RequestMapping("/toShowMake/{id}")
	public String selectMakeManager(Model model, @PathVariable int id) throws Exception {
		BuildMake buildMake = buildMakeService.selectById(id);
		Integer buildId = buildMake.getBuildId();
		Integer makeId = buildMake.getMakeId();
		TBuild tBuild = IBulidServcie.selectBuildById(buildId);
		TMake tMake = makeService.selectMakeById(makeId);
		buildMake.setBuild(tBuild);
		buildMake.setMake(tMake);
		model.addAttribute("tMake", buildMake);
		return "/admin/showMake.jsp";
	}
	// 跳转到修改构造信息
	@RequestMapping("/toUpdateMake/{id}")
	public String updateMakeManager(Model model, @PathVariable int id) throws Exception {
		BuildMake buildMake = buildMakeService.selectById(id);
		Integer buildId = buildMake.getBuildId();
		Integer makeId = buildMake.getMakeId();
		TBuild tBuild = IBulidServcie.selectBuildById(buildId);
		TMake tMake = makeService.selectMakeById(makeId);
		buildMake.setBuild(tBuild);
		buildMake.setMake(tMake);
		model.addAttribute("buildMake", buildMake);
		return "/admin/updateMake.jsp";
	}
	// 提交修改
	@RequestMapping("/updateMakeSuccess")
	public @ResponseBody void updateMakeSuccess(TMake make) throws Exception {
		makeService.updateMakeById(make);
		TLog log = new TLog(2, "修改构造信息："+make.getName(),new Date());
		logService.insertLog(log);
	}
	
	// 删除建筑-构造信息表的内容和对应的构造记录
		@RequestMapping("/toDeleteMake/{id}")
		public @ResponseBody void deleteMakeManager(@PathVariable int id) throws Exception {
			Integer makeId = buildMakeService.selectById(id).getMakeId();
			buildMakeService.deleteBuildMakeById(id);
			makeService.deleteMakeById(makeId);
			TLog log = new TLog(2, "删除构造信息", new Date());
			logService.insertLog(log);
		}

}
