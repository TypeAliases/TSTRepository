package com.sust.web.controller.admin;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class MaterialManagerController {
	
	
	
	@RequestMapping("toMaterialManager/{curPage}")
	public String toMaterialManager(Model model,@PathVariable int curPage) {
		
		return "/admin/materialManager.jsp";
	}

}
